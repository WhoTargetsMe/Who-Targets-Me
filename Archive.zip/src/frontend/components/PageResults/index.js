import PageResults from './PageResults'
export default PageResults
