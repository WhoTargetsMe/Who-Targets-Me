import PageRegister from './PageRegister'
export default PageRegister
